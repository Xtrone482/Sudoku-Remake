public class SudokuCodierung{
  private int x = 0;
  private int Spielfeld[][] = new int [8][8];
  
  public void SudokuCodierung (Felder a[][]){
    for (int i = 0; i < 9; i++) {
      for (int j = 0; j < 9; j++) {
        //Übersetzer
      }
    }
  }
  
  public void SudokuCodierung (int a[][]){
    Spielfeld = a;
  }
  
  public int getCode(){
    for (int i = 0; i < 9; i++) {
      
    }
    }  
  }